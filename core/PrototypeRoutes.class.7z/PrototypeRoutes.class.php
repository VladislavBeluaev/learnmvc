<?php
/**
 * Created by PhpStorm.
 * User: Dragon
 * Date: 01.12.2018
 * Time: 21:50
 */

namespace Acme\core;


/**
 * Class PrototypeRoutes
 * @package Acme\core
 */
class PrototypeRoutes
{
    /**
     * @var
     */
    private static $routeInstance;
    /**
     * @var array
     */
    private $prototypeRoutes;
    /**
     * @var string
     */
    //private $parameterSearchPattern;
    /**
     * PrototypeRoutes constructor.
     */
    private function __construct(){
        $this->prototypeRoutes = array(
            "GET"=>[],
            "POST"=>[]
        );
        //$this->parameterSearchPattern = '/[a-z].*({\w+\??})/iU';
    }

    /**
     *
     */
    private function __clone(){}

    /**
     * @param string $routesFile
     * @return PrototypeRoutes
     * @throws \Exception
     */
    static function load(string $routesFile):PrototypeRoutes
    {
        if(!file_exists($routesFile)) throw new \Exception("Route file not found");
        if(!is_null(self::$routeInstance)) return self::$routeInstance;
        $router = self::$routeInstance = new self();
        require_once $routesFile;
        return $router;
    }

    /**
     * @param string $url
     * @param mixed $controller
     */
    function get(string $url, $controller){
        $this->prototypeRoutes['GET'][$url] = $controller;
    }

    /**
     * @param string $url
     * @param string $controller
     */
    function post(string $url, string $controller){
        $this->prototypeRoutes['POST'][$url] = $controller;
    }

    /**
     * @param string $url
     * @param string $requestMethod
     * @return mixed
     * @throws \Exception
     */
    function directTo(string $url, string $requestMethod){
        if(!$findRoute = $this->isRouteExists($url,$requestMethod))
        {
            throw new \Exception("This page not found");
        }
        $callActionWith = array_merge(explode('@', $this->prototypeRoutes[$requestMethod][$findRoute]), array($this->getRequestValues($url)));
        return $this->callAction(...$callActionWith);
    }

    /**
     * @param string $url
     * @param string $requestMethod
     * @return string
     */
    protected function isRouteExists(string $url, string $requestMethod){
        $sizeOfUserRequestArray = $this->sizeOfArray($url);
        $userRequestParams = $this->filterUrlArray($url,function($key){
            return (!($key & 1));
        });
        foreach (array_keys($this->prototypeRoutes[$requestMethod]) as $prototypeRoute)
        {
            $sizeOfPrototypeRouteArray = $this->sizeOfArray($prototypeRoute);
            $prototypeRequestParams = $this->filterUrlArray($prototypeRoute,function($key){
                return (!($key & 1));
            });
            if($userRequestParams===$prototypeRequestParams && $sizeOfPrototypeRouteArray==$sizeOfUserRequestArray)
            {
                return $prototypeRoute;
            }
        }
        return '';
    }

    /**
     * @param $controller
     * @param $action
     * @param array $actionParams
     * @return mixed
     * @throws \ReflectionException
     */
    protected function callAction($controller, $action, $actionParams=[]){
        $controllerRef = new \ReflectionClass("Acme\\controllers\\".$controller);
        if(!$controllerRef->implementsInterface('Acme\\core\\IController')) throw new \ReflectionException("Invalid controller $controller class passed to ReflectionClass.");
        if($controllerRef->hasMethod('__construct'))
        {
            $contextContainer = Container::getInstance()->get($controller);
            $controllerRefConstruct = $controllerRef->getMethod('__construct');
            $controllerRefConstructParams = $controllerRefConstruct->getParameters();
            var_dump($controllerRefConstructParams);
            $argsToConstruct = [];
            foreach ($controllerRefConstructParams as $value) {

                if(!is_null($value->getClass()))
                {  
                    $argsToConstruct[] = $this->getInstanceByKey($value,$contextContainer);
                }
            }
        if(!$controllerRef->hasMethod($action)) throw new \ReflectionException("A non-existent method $action called in class $controller.");
        $controllerRefMethod = $controllerRef->getMethod($action);
        if($controllerRefMethod->getNumberOfParameters())
        {
            $controllerRefMethodFirstParam = $controllerRefMethod->getParameters()[0];
            if(!is_null($controllerRefMethodFirstParam->getClass()))
            {
                $instanceFromContainer = Container::getInstance()->get($controllerRefMethodFirstParam->getClass()->getShortName());
                array_unshift($actionParams,$instanceFromContainer);
            }
        }
        $controllerRefInstance = $controllerRef->newInstanceArgs($argsToConstruct);
        return $controllerRefMethod->invokeArgs($controllerRefInstance,$actionParams);
    }
}

    /**
     * @param string $url
     * @return array
     */
    protected function getRequestValues(string $url/*,string $requestMethod*/):array {
        return array_filter(explode('/',trim($url,'/')),function($key){
            return ($key & 1);
        },ARRAY_FILTER_USE_KEY);
        /*preg_match_all($this->parameterSearchPattern,$this->prototypeRoutes[$requestMethod][$url],$prototypeRouteValues,PREG_PATTERN_ORDER);
        var_dump($this->prototypeRoutes[$requestMethod]);
        $prototypeRouteValues = array_map(function($param){
            return strpos($param,'?')!==FALSE?ucfirst(trim($param,"{}?")):ucfirst(trim($param,"{}"));
        },$prototypeRouteValues[1]);
        var_dump($prototypeRouteValues);
        $userRequestValues = $this->filterUrlArray($url,function($key){
            return ($key & 1);
        });
        var_dump($userRequestValues);
        return array_combine($prototypeRouteValues,$userRequestValues);*/
    }

    /**
     * @param string $request
     * @return int
     */
    private function sizeOfArray(string $request):int
    {
        return count(explode('/',trim($request,'/')));
    }

    /**
     * @param string $url
     * @param callable $callback
     * @param string $stringDelimiter
     * @return array
     */
    private function filterUrlArray(string $url, callable $callback, $stringDelimiter='/'):array
    {
        return array_filter(explode($stringDelimiter,trim($url,$stringDelimiter)),$callback,ARRAY_FILTER_USE_KEY);
    }
    private function getInstanceByKey($key,$context=null)
    {
        return is_null($context)?Container::getInstance()->get($key->getClass()->getShortName()):
            $context[$key->getClass()->getShortName()];
    }
}